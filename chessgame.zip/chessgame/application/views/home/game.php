<html>
	<head>
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/chess.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/fa/css/all.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/chessboard-1.0.0.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/chessboard-1.0.0.min.css">
		
	</head>
	<body class="body-bg">
		<nav class="navbar navbar-expand-lg main-navbar">
			<div class="mr-auto"></div>
		</nav>
		<div class="main-art">
			<div id="divTimer" class="timer">
				Game will be start in 5 seconds
			</div>
			<div id="myBoard" class="chessboard"></div>
			
			<div class="card player-card">
				<div class="card-player-header header-black">
					<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
					<a href="#">Your name</a>
					<div id="divBlackTimer" class="player-time"></div>
				</div>
				<div id="divKilledWhite">
					
				</div>
			</div>
			<div class="card player-card">
				<div class="card-player-header header-white">
					<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
					<a href="#">Your name</a>
					<div id="divWhiteTimer" class="player-time"></div>
				</div>
				<div id="divKilledBlack">
					
				</div>
			</div>
			<div class="player-card">
				<button data-toggle="modal" data-target="#EngGameModal" class="btn btn-danger btn-block">End Game</button>
				<div id="EngGameModal" class="modal fade" role="dialog">
					<div class="modal-dialog">

					<!-- Modal content-->
						<div class="modal-content">
							<div class="modal-header">
								<h4 class="modal-title">Enging Game</h4>
								<button type="button" class="close" data-dismiss="modal">&times;</button>
							</div>
							<div class="modal-body">
								<p>By ending this game, you will lose. If your are playing with login then it can hurt your rankings</p>
							</div>
							<div class="modal-footer">
								<a href="#" class="btn btn-primary" data-dismiss="modal">Continue Game</a>
								<a href="<?php echo site_url('home/index'); ?>" class="btn btn-danger">End Game</a>
							</div>
						</div>

					</div>
				</div>
				<div id="WinGame" class="modal fade" role="dialog">
					<div class="modal-dialog">

					<!-- Modal content-->
						<div class="modal-content">
							<div class="modal-header">
								<h4 class="modal-title">Game Won</h4>
								<button type="button" class="close" data-dismiss="modal">&times;</button>
							</div>
							<div class="modal-body">
								<p>Congratulation, You Won the Game. Press OK to go back on main page.</p>
							</div>
							<div class="modal-footer">
								<a href="<?php echo site_url('home/index'); ?>" class="btn btn-primary">OK</a>
							</div>
						</div>

					</div>
				</div>
			</div>
			<div id="output" style="background-color: #fff;"></div>
		</div>
		<input type="hidden" id="hidBaseURL" value="<?php echo base_url(); ?>" />
		<input type="hidden" id="hidGameType" value="<?php echo $game_type; ?>" />
		<script src="<?php echo base_url(); ?>assets/js/jquery.3.6.0.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/chess.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/chessboard-1.0.0.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/chessboard-1.0.0.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/app.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/easy-opponent.js"></script>
		<script>
			var timer = setInterval(gameStartTimer, 1000);
			var seconds_rem = 5;
			var divTimer = document.getElementById('divTimer');
			function gameStartTimer() 
			{
				divTimer.innerHTML = "Game will be start in " + seconds_rem + " seconds";
				seconds_rem--;
	
				if (seconds_rem < 5)
				{
					clearInterval(timer);
					startGame('<?php echo base_url();?>');
				}				
			}			
		</script>
	</body>
</html>
