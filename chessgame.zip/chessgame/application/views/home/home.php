<html>
	<head>
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/chess.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/fa/css/all.css">

	</head>
	<body class="body-bg">
		<div class="page-title">Chess Game</div>
		<nav class="navbar navbar-expand-lg main-navbar">
			<div class="mr-auto"></div>
			<?php 
				//if ($user_data)
					//echo $user_menu;
				//else
					//echo "<a href='#' class='login-button btn btn-primary'>Login</a>";
			?>
		</nav>
		<div class="list-container">
			<div class="link-box-container">
				<ul class="main-list-options">
					<li>	
						<a href="<?php echo site_url() . '/home/game/1'; ?>"><div class="link-box">Quick Game</div></a>
					</li>
					<li>
						<a href="<?php echo site_url('player') ; ?>"><div class="link-box">Login</div></a>
					</li>
					<li>
						<a href="<?php echo site_url('player/signup')  ?>"><div class="link-box">Signup</div></a>
					</li>
					<li>
						<div class="link-box">About</div></a>
					</li>
				</ul>
			</div>	  
	  	</div>
		    <div class="play-list">
			
				<ul class="main-play-list-option">
					<li>	
						<a href="<?php echo site_url() . '/home/game/1'; ?>"><div class="link-play"> Play </div></a>
					</li>
            </div>
		<script src="assets/js/jquery-3.4.1.min.js"></script>
		<script src="assets/js/scripts.js"></script>
		<script src="assets/js/custom.js"></script>
		<script src="assets/js/bootstrap.min.js">
	</body>
</html>
